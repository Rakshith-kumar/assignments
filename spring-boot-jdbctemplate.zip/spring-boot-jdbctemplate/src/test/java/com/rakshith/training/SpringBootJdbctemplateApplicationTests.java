package com.rakshith.training;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJdbctemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
