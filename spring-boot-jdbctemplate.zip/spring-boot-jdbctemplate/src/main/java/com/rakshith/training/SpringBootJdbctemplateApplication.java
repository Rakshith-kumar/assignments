package com.rakshith.training;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJdbctemplateApplication {
   
	public static void main(String[] args) {
		SpringApplication.run(SpringBootJdbctemplateApplication.class, args);
	}

}
