package com.spring.dao;

import java.util.List;

import com.spring.bean.Wallet;
import com.spring.before.AccountAuthentication;
import com.spring.exception.AccountAlreadyExistsException;
import com.spring.exception.LowBalanceException;

public interface WalletDao {
	
	public String createWalletAccount(String accountId,String accountPin,AccountAuthentication authenticate) throws org.springframework.dao.EmptyResultDataAccessException, AccountAlreadyExistsException;
	public String FundTransfer(String walletId,String password,AccountAuthentication authenticate,String accountId) throws org.springframework.dao.EmptyResultDataAccessException, LowBalanceException,java.util.InputMismatchException;
	public double checkBalance(String walletId,String password,AccountAuthentication authenticate) throws org.springframework.dao.EmptyResultDataAccessException ;
	public String withdraw(String  walletId,String password,AccountAuthentication authenticate) throws org.springframework.dao.EmptyResultDataAccessException, LowBalanceException,java.util.InputMismatchException;
	public String deposit(String  walletId,String password,AccountAuthentication authenticate) throws org.springframework.dao.EmptyResultDataAccessException,com.spring.exception.InsufficientWalletBalanceException,java.util.InputMismatchException;
	
}
