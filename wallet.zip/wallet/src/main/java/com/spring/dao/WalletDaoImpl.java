package com.spring.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.spring.bean.Account;
import com.spring.bean.SelfTransactions;
import com.spring.bean.Transactions;
import com.spring.bean.Wallet;
import com.spring.before.AccountAuthentication;
import com.spring.exception.AccountAlreadyExistsException;
import com.spring.exception.LowBalanceException;

@Component("walletDaoImpl")
public class WalletDaoImpl implements WalletDao{
	java.util.Scanner scanner=new java.util.Scanner(System.in);
	@Autowired
	org.springframework.jdbc.core.JdbcTemplate jdbcTemplate;

	public String createWalletAccount(String accountId,String accountPin,AccountAuthentication authenticate) throws org.springframework.dao.EmptyResultDataAccessException, AccountAlreadyExistsException {
		String sql="SELECT * FROM ACCOUNT WHERE ACCOUNT_ID=? AND ACCOUNT_PIN=?";
	
		 com.spring.bean.Account account=jdbcTemplate.queryForObject(sql,new Object[]{accountId,accountPin},new org.springframework.jdbc.core.
				                 BeanPropertyRowMapper<com.spring.bean.Account>(Account.class));
	      String walletId=authenticate.WalletIdCreation(accountId);
	       System.out.println("enter the password you want to set for wallet application");
	       String password=scanner.nextLine();
	       System.err.println("enter the username");
	       String userName=scanner.nextLine();
	       int Balance=0;
	       sql="Insert into Wallet values('"+walletId+"','"
	       		                            + accountId+"','"
	       	                             	+ userName+"','"
	       	                             	+Balance +"','"
	       	                             	+password+"')";
	       jdbcTemplate.update(sql);
	       return walletId;
	       	                             	
	}

	public String FundTransfer(String walletId,String password,AccountAuthentication authenticate,String accountId) throws org.springframework.dao.EmptyResultDataAccessException, LowBalanceException {
		Wallet wallet=authenticate.walletIdAuthentication(walletId, password);
		
		String sql="select * from Account where ACCOUNT_ID=?";
		 Account account=jdbcTemplate.queryForObject(sql,new Object[]{accountId},new org.springframework.jdbc.core.
                 BeanPropertyRowMapper<com.spring.bean.Account>(Account.class));
		 System.out.println("this transfer is from account to account");
		 System.out.println("enter the amount you want to transfer");
		double amount=scanner.nextDouble();
		    scanner.nextLine();
		double accountBalance=checkBalance(walletId, password, authenticate);
		 if((accountBalance-amount)<1000){
			 throw new com.spring.exception.LowBalanceException("account balance is low"); 
		 }else{
			double newAccountBalance=accountBalance-amount;
			double anotherNewAccountBalance=account.getACCOUNT_BALANCE()+amount;
			 String sql1="update Account set ACCOUNT_BALANCE=? where ACCOUNT_ID=?";
			 jdbcTemplate.update(sql1, new Object[]{newAccountBalance,wallet.getAccountId()});
			  String sql2="update Account set ACCOUNT_BALANCE=? where ACCOUNT_ID=?";
			  jdbcTemplate.update(sql2, new Object[]{anotherNewAccountBalance,accountId});
			  double credit=0;
			  double debit=amount;
			  String transactionId=authenticate.accountTransactions(accountId, wallet, credit, debit);
			  System.out.println("your account debited Rs"+debit);
			  return transactionId;
			 
		 }
		  
		    
		  
	    
	}

	public double checkBalance(String walletId,String password,AccountAuthentication authenticate) throws org.springframework.dao.EmptyResultDataAccessException {
		// TODO Auto-generated method stub
		/* String sql="select * from wallet where WALLET_ID=?";
		 Wallet wallet=jdbcTemplate.queryForObject(sql,new Object[]{walletId}, new org.springframework.jdbc.core.BeanPropertyRowMapper<Wallet>(Wallet.class));
		 System.out.println("wallet balance="+wallet.getBalance());*/
		  Wallet wallet=authenticate.walletIdAuthentication(walletId, password);
		  System.out.println("Initial walletbalance="+wallet.getBalance());
		 String sql="select * from Account where ACCOUNT_ID=?";
	      Account account=jdbcTemplate.queryForObject(sql,new Object[]{wallet.getAccountId()},new org.springframework.jdbc.core.BeanPropertyRowMapper<Account>(Account.class));
	      return account.getACCOUNT_BALANCE();
	}

	public String withdraw(String  walletId,String password,AccountAuthentication authenticate) throws org.springframework.dao.EmptyResultDataAccessException, LowBalanceException{
		// TODO Auto-generated method stub
		 Wallet wallet=authenticate.walletIdAuthentication(walletId, password);
		 System.out.println("enter the amount to withdraw");
		 double amount=scanner.nextDouble();
		 scanner.nextLine();
		double  accountBalance=checkBalance(  walletId,password, authenticate);
		if((accountBalance-amount)<1000){
			throw new com.spring.exception.LowBalanceException("account balance is low");
		}
		else
		{
			double dbaccountBalance=accountBalance-amount;
			String sql="update Account set ACCOUNT_BALANCE=? where ACCOUNT_ID=?";
			jdbcTemplate.update(sql, new Object[]{dbaccountBalance,wallet.getAccountId()});
			double newWalletBalance=wallet.getBalance()+amount;
			String sql1="update wallet set WALLET_BALANCE=? Where WALLET_ID=?";
			jdbcTemplate.update(sql1,new Object[]{newWalletBalance,wallet.getWalletId()});
			
			 double debit=0.0;
			 double credit=amount;
			String TransactionId=authenticate.wallettransaction(wallet,debit,credit);
			 System.out.println("your wallet got credited from your account Rs:"+newWalletBalance);
			 return TransactionId;
			
			}
		 
		
		
		}
		 
		 
		   
		
	

	public String deposit(String  walletId,String password,AccountAuthentication authenticate) throws org.springframework.dao.EmptyResultDataAccessException,com.spring.exception.InsufficientWalletBalanceException{

		Wallet wallet=authenticate.walletIdAuthentication(walletId, password);
		System.out.println(wallet.getBalance());
		 System.out.println("enter the amount to deposit to the bank");
		 double amount=scanner.nextDouble();
		 scanner.nextLine();
		/* String sql="select * from Account where ACCOUNT_ID=?";
	      Account account=jdbcTemplate.queryForObject(sql,new Object[]{wallet.getAccountId()},new org.springframework.jdbc.core.BeanPropertyRowMapper<Account>(Account.class));*/
	     
		double  accountBalance=checkBalance(walletId, password, authenticate);
		//checkBalance(  walletId,password, authenticate);
		if((amount)>wallet.getBalance()){
			throw new com.spring.exception.InsufficientWalletBalanceException("your wallet balance has less money than the amount you are requesting "
					                                                    +"to deposit to the bank account ");
		}
		else
		{
			double dbaccountBalance=accountBalance+amount;
			String sql1="update Account set ACCOUNT_BALANCE=? where ACCOUNT_ID=?";
			jdbcTemplate.update(sql1, new Object[]{dbaccountBalance,wallet.getAccountId()});
			double newWalletBalance=wallet.getBalance()-amount;
			String sql2="update wallet set WALLET_BALANCE=? Where WALLET_ID=?";
			jdbcTemplate.update(sql2,new Object[]{newWalletBalance,wallet.getWalletId()});
			
			 double debit=amount;
			 double credit=0.0;
			String TransactionId=authenticate.wallettransaction(wallet,debit,credit);
			 System.out.println("your wallet got debited from your account Rs:"+newWalletBalance);
			 return TransactionId;
			
			}
		 
	   
	}
	public void transactions(String  walletId,String password,AccountAuthentication authenticate) throws org.springframework.dao.EmptyResultDataAccessException{
		  
		List <SelfTransactions> selfTransaction=authenticate.getAllSelfTransactions();
		List <Transactions> accountTransaction=authenticate.getAllTransactions();
		System.out.println("transactions from account to wallet and wallet to account");
		 for(SelfTransactions transaction:selfTransaction){
			 System.out.println(transaction);
		 }
		 System.out.println("transactions from account  to account");
		 for(Transactions transaction:accountTransaction){
			 System.out.println(transaction);
		 }
	 }
}
