package com.spring.bean;

public class WalletTransactions {

	private String transactionId;
	private String walletId;
	private String transactedWalletId;
	private double debitedAmount;
	private double creditedAmount;
	private String transactionTime;
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getWalletId() {
		return walletId;
	}
	public void setWalletId(String walletId) {
		this.walletId = walletId;
	}
	public String getTransactedWalletId() {
		return transactedWalletId;
	}
	public void setTransactedWalletId(String transactedWalletId) {
		this.transactedWalletId = transactedWalletId;
	}
	public double getDebitedAmount() {
		return debitedAmount;
	}
	public void setDebitedAmount(double debitedAmount) {
		this.debitedAmount = debitedAmount;
	}
	public double getCreditedAmount() {
		return creditedAmount;
	}
	public void setCreditedAmount(double creditedAmount) {
		this.creditedAmount = creditedAmount;
	}
	public String getTransactionTime() {
		return transactionTime;
	}
	public void setTransactionTime(String transactionTime) {
		this.transactionTime = transactionTime;
	}
	@Override
	public String toString() {
		return "WalletTransactions [transactionId=" + transactionId + ", walletId=" + walletId + ", transactedWalletId="
				+ transactedWalletId + ", debitedAmount=" + debitedAmount + ", creditedAmount=" + creditedAmount
				+ ", transactionTime=" + transactionTime + "]";
	}
	
	
}
